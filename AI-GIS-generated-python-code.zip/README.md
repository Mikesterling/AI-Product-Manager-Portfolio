# AI-GIS

自然语言交互 + GIS 工具调用 + 空间分析计算 + 可视化表达。

## 后端启动

```bash
cd backend
pip install -r requirements.txt
python run.py
```

访问：`http://127.0.0.1:8000/docs`
