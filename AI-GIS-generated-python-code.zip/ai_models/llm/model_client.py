class LocalModelClient:
    def __init__(self, config_path: str | None=None): self.config_path=config_path
    def generate(self, prompt: str) -> str: return '本地模型尚未接入。'
