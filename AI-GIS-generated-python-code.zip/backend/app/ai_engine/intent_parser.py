from app.ai_engine.tool_registry import GIS_TOOL_REGISTRY
def parse_intent(user_query: str) -> dict:
    text=user_query.lower().strip()
    for intent, meta in GIS_TOOL_REGISTRY.items():
        for kw in meta['keywords']:
            if kw.lower() in text or kw in user_query: return {'intent':intent,'tool':meta['tool'],'confidence':0.85,'method':'keyword_rule'}
    return {'intent':'summary','tool':'summary','confidence':0.3,'method':'fallback'}
