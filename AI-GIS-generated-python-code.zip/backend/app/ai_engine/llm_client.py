class LLMClient:
    def __init__(self, provider: str='rule'): self.provider=provider
    def chat(self, prompt: str) -> str: return 'LLM 尚未接入，目前使用规则解析。'
