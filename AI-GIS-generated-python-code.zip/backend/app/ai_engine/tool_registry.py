GIS_TOOL_REGISTRY={
 'feature_count':{'name':'要素数量统计','keywords':['要素数量','多少个要素','feature count','count'],'tool':'feature_count'},
 'columns':{'name':'字段查看','keywords':['字段','字段名','属性表','columns','fields'],'tool':'columns'},
 'geometry_types':{'name':'几何类型查看','keywords':['几何类型','geometry','geometry type'],'tool':'geometry_types'},
 'crs':{'name':'坐标系查看','keywords':['坐标系','投影','crs','projection'],'tool':'crs'},
 'bounds':{'name':'空间范围查看','keywords':['范围','边界','bounds','bbox','extent'],'tool':'bounds'},
 'area':{'name':'面积计算','keywords':['面积','area'],'tool':'area'},
 'length':{'name':'长度/周长计算','keywords':['周长','长度','perimeter','length'],'tool':'length'},
 'summary':{'name':'数据概览','keywords':['概览','总结','summary','overview'],'tool':'summary'},
}
