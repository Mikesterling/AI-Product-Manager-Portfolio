from app.ai_engine.intent_parser import parse_intent
from app.gis_tools.vector.basic_info import get_feature_count, get_columns, get_geometry_types, get_crs, get_bounds, get_summary
from app.gis_tools.vector.geometry_calc import calculate_total_area, calculate_total_length

def run_vector_tool(gdf, user_query: str) -> dict:
    intent=parse_intent(user_query); tool=intent['tool']
    if tool=='feature_count': result=get_feature_count(gdf)
    elif tool=='columns': result=get_columns(gdf)
    elif tool=='geometry_types': result=get_geometry_types(gdf)
    elif tool=='crs': result=get_crs(gdf)
    elif tool=='bounds': result=get_bounds(gdf)
    elif tool=='area': result=calculate_total_area(gdf)
    elif tool=='length': result=calculate_total_length(gdf)
    else: result=get_summary(gdf)
    result['query']=user_query; result['intent']=intent
    if 'success' not in result: result['success']=True
    return result
