from fastapi import APIRouter
from app.schemas.request import QueryRequest
from app.services.ai_service import analyze_text_intent
router=APIRouter()
@router.post('/intent')
def intent_parse(request: QueryRequest): return analyze_text_intent(request.text)
