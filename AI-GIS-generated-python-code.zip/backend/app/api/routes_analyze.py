from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from app.services.file_service import save_upload_file, read_vector_file
from app.services.analyze_service import analyze_vector_by_text
from app.schemas.request import QueryRequest
from app.ai_engine.intent_parser import parse_intent
router=APIRouter()
@router.post('/text')
def analyze_text(request: QueryRequest): return {'success': True, 'input_text': request.text, 'intent': parse_intent(request.text), 'result': f'你输入的内容是：{request.text}'}
@router.post('/smart')
async def smart_analyze(file: UploadFile = File(...), text: str = Form(...)):
    try:
        saved=await save_upload_file(file); gdf=read_vector_file(saved['saved_path']); result=analyze_vector_by_text(gdf, text); result['filename']=file.filename; result['saved_path']=saved['saved_path']; return result
    except ValueError as e: raise HTTPException(status_code=400, detail=str(e))
    except Exception as e: raise HTTPException(status_code=500, detail=f'智能分析失败: {str(e)}')
