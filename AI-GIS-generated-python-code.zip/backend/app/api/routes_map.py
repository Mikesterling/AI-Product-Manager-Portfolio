from fastapi import APIRouter, UploadFile, File, HTTPException
from app.services.file_service import save_upload_file
from app.services.map_service import preview_vector_as_geojson
router=APIRouter()
@router.post('/preview')
async def preview_map(file: UploadFile = File(...)):
    try:
        saved=await save_upload_file(file); result=preview_vector_as_geojson(saved['saved_path']); result['filename']=file.filename; return result
    except Exception as e: raise HTTPException(status_code=500, detail=f'地图预览失败: {str(e)}')
