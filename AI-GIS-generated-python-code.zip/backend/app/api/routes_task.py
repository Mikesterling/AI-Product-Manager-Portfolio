from fastapi import APIRouter
from app.services.task_service import create_task, get_task
router=APIRouter()
@router.post('/create')
def create_demo_task(): return create_task('演示任务已创建，后续可接入 Celery。')
@router.get('/{task_id}')
def read_task(task_id: str): return get_task(task_id)
