from fastapi import APIRouter, UploadFile, File, HTTPException
from app.services.upload_service import handle_upload
router=APIRouter()
@router.post('')
async def upload_file(file: UploadFile = File(...)):
    try: return await handle_upload(file)
    except Exception as e: raise HTTPException(status_code=500, detail=f'文件上传失败: {str(e)}')
