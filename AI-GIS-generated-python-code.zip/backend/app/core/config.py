from pathlib import Path
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    PROJECT_NAME: str = 'AI-GIS'
    VERSION: str = '0.1.0'
    BASE_DIR: Path = Path(__file__).resolve().parents[2]
    UPLOAD_DIR: Path = BASE_DIR.parent / 'uploads'
    EXTRACT_DIR: Path = BASE_DIR.parent / 'extracted'
    OUTPUT_DIR: Path = BASE_DIR.parent / 'outputs'
    STATIC_DIR: Path = BASE_DIR.parent / 'static'
    MAX_UPLOAD_SIZE_MB: int = 500
    CORS_ORIGINS: list[str] = ['http://localhost:5173','http://127.0.0.1:5173','http://localhost:3000','http://127.0.0.1:3000']
    class Config:
        env_file = '.env'
        env_file_encoding = 'utf-8'
settings = Settings()
for p in [settings.UPLOAD_DIR, settings.EXTRACT_DIR, settings.OUTPUT_DIR, settings.STATIC_DIR]:
    p.mkdir(parents=True, exist_ok=True)
