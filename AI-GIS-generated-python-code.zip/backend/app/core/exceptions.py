from fastapi import HTTPException
class AIGISException(Exception): pass
class UnsupportedFileTypeError(AIGISException): pass
class GISReadError(AIGISException): pass
def http_bad_request(message: str) -> HTTPException: return HTTPException(status_code=400, detail=message)
def http_server_error(message: str) -> HTTPException: return HTTPException(status_code=500, detail=message)
