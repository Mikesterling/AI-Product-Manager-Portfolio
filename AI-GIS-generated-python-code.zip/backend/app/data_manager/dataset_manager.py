from app.core.config import settings
def list_uploaded_files() -> list[dict]:
    return [{'name':p.name,'path':str(p),'size_bytes':p.stat().st_size} for p in settings.UPLOAD_DIR.glob('*') if p.is_file()]
