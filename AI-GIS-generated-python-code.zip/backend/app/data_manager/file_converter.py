import geopandas as gpd
def vector_to_geojson(input_path: str, output_path: str) -> str:
    gdf=gpd.read_file(input_path); gdf.to_file(output_path, driver='GeoJSON'); return output_path
