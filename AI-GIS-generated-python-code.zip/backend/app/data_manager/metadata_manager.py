import json
from pathlib import Path
def save_metadata(path, metadata: dict) -> str:
    p=Path(path); p.parent.mkdir(parents=True, exist_ok=True); p.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8'); return str(p)
def load_metadata(path) -> dict:
    p=Path(path); return json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}
