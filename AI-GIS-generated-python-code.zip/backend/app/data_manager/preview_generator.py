from app.services.file_service import read_vector_file
def generate_vector_preview(file_path: str, max_rows: int=20) -> dict:
    gdf=read_vector_file(file_path); preview=gdf.drop(columns='geometry', errors='ignore').head(max_rows); return {'rows':preview.to_dict(orient='records'),'columns':list(preview.columns),'feature_count':len(gdf)}
