import numpy as np
def idw_predict(known_xy, known_values, unknown_xy, power: float=2.0, k: int | None=12, eps: float=1e-12):
    known_xy=np.asarray(known_xy,float); known_values=np.asarray(known_values,float).reshape(-1); unknown_xy=np.asarray(unknown_xy,float); preds=[]
    for p in unknown_xy:
        dist=np.linalg.norm(known_xy-p, axis=1)
        if np.any(dist<eps): preds.append(float(known_values[np.argmin(dist)])); continue
        idx=np.argpartition(dist, k)[:k] if k is not None and k < len(dist) else slice(None)
        d=dist[idx]; v=known_values[idx]; w=1.0/(d**power+eps); preds.append(float((w*v).sum()/w.sum()))
    return np.asarray(preds)
