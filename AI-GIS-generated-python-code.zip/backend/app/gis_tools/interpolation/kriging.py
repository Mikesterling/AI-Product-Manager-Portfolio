def ordinary_kriging_predict(known_xy, known_values, unknown_xy, variogram_model: str='linear'):
    import numpy as np
    try: from pykrige.ok import OrdinaryKriging
    except ImportError as exc: raise ImportError('请先安装 PyKrige: pip install pykrige') from exc
    known_xy=np.asarray(known_xy,float); known_values=np.asarray(known_values,float).reshape(-1); unknown_xy=np.asarray(unknown_xy,float)
    ok=OrdinaryKriging(known_xy[:,0], known_xy[:,1], known_values, variogram_model=variogram_model, verbose=False, enable_plotting=False)
    z,ss=ok.execute('points', unknown_xy[:,0], unknown_xy[:,1]); return np.asarray(z, dtype=float)
