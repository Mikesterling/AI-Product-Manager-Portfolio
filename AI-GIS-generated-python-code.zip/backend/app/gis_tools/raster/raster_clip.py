def clip_raster_by_vector(raster_path: str, vector_path: str, output_path: str) -> str:
    import geopandas as gpd, rasterio
    from rasterio.mask import mask
    gdf=gpd.read_file(vector_path)
    with rasterio.open(raster_path) as src:
        if gdf.crs and src.crs and gdf.crs != src.crs: gdf=gdf.to_crs(src.crs)
        out_image,out_transform=mask(src, gdf.geometry, crop=True); meta=src.meta.copy(); meta.update({'height':out_image.shape[1],'width':out_image.shape[2],'transform':out_transform})
    with rasterio.open(output_path, 'w', **meta) as dst: dst.write(out_image)
    return output_path
