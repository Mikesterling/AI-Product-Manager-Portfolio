def get_raster_info(path: str) -> dict:
    try: import rasterio
    except ImportError as exc: raise ImportError('请先安装 rasterio: pip install rasterio') from exc
    with rasterio.open(path) as src:
        return {'width':src.width,'height':src.height,'count':src.count,'crs':str(src.crs) if src.crs else None,'bounds':{'left':src.bounds.left,'bottom':src.bounds.bottom,'right':src.bounds.right,'top':src.bounds.top},'dtype':src.dtypes[0] if src.dtypes else None,'nodata':src.nodata}
