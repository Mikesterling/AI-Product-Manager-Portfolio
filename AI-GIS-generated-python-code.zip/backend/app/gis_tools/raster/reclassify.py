def reclassify_array(array, rules):
    import numpy as np
    out=np.full(array.shape, np.nan, dtype=float)
    for low, high, value in rules: out[(array>=low)&(array<high)] = value
    return out
