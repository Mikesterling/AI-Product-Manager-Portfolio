def zonal_statistics(vector_path: str, raster_path: str, stats=None):
    try: from rasterstats import zonal_stats
    except ImportError as exc: raise ImportError('请先安装 rasterstats: pip install rasterstats') from exc
    return zonal_stats(vector_path, raster_path, stats=stats or ['mean','min','max','count'])
