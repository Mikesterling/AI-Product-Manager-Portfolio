def geodetector_q(df, y_field: str, strata_field: str) -> dict:
    import numpy as np
    data=df[[y_field, strata_field]].dropna(); y=data[y_field].to_numpy(dtype=float); n=len(y)
    if n<=1: return {'q':None,'error':'样本量不足'}
    total_var=np.var(y, ddof=1)
    if total_var==0: return {'q':0.0,'note':'因变量方差为 0'}
    within=0.0
    for _,grp in data.groupby(strata_field):
        yh=grp[y_field].to_numpy(dtype=float); 
        if len(yh)>1: within += len(yh)*np.var(yh, ddof=1)
    q=1.0-within/(n*total_var); return {'y_field':y_field,'strata_field':strata_field,'q':float(q),'n':int(n),'strata_count':int(data[strata_field].nunique())}
