def local_moran(gdf, value_field: str, k: int=8):
    from libpysal.weights import KNN
    from esda.moran import Moran_Local
    c=gdf.geometry.centroid; w=KNN.from_array(list(zip(c.x,c.y)), k=k); w.transform='r'; lisa=Moran_Local(gdf[value_field].values, w)
    out=gdf.copy(); out['local_I']=lisa.Is; out['local_p']=lisa.p_sim; out['quadrant']=lisa.q; return out
