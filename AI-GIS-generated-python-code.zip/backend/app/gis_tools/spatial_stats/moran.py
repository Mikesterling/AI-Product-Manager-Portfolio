def moran_i(gdf, value_field: str, k: int=8) -> dict:
    try:
        from libpysal.weights import KNN
        from esda.moran import Moran
    except ImportError as exc: raise ImportError('请先安装 libpysal 和 esda: pip install libpysal esda') from exc
    if value_field not in gdf.columns: raise ValueError(f'字段不存在: {value_field}')
    c=gdf.geometry.centroid; w=KNN.from_array(list(zip(c.x,c.y)), k=k); w.transform='r'; mi=Moran(gdf[value_field].values, w)
    return {'field':value_field,'moran_i':float(mi.I),'p_value':float(mi.p_sim),'z_score':float(mi.z_sim),'k':k}
