def empirical_semivariogram(coords, values, max_lag=None, n_bins: int=12) -> dict:
    import numpy as np
    coords=np.asarray(coords,float); values=np.asarray(values,float).reshape(-1); dists=[]; semivars=[]
    for i in range(len(values)):
        for j in range(i+1,len(values)):
            dists.append(np.linalg.norm(coords[i]-coords[j])); semivars.append(0.5*(values[i]-values[j])**2)
    dists=np.asarray(dists); semivars=np.asarray(semivars); max_lag=float(np.percentile(dists,90) if max_lag is None else max_lag)
    bins=np.linspace(0,max_lag,n_bins+1); centers=0.5*(bins[:-1]+bins[1:]); gamma=[]
    for low, high in zip(bins[:-1], bins[1:]):
        m=(dists>=low)&(dists<high); gamma.append(float(np.nanmean(semivars[m])) if m.any() else None)
    return {'lag':centers.tolist(),'semivariance':gamma,'max_lag':max_lag,'n_pairs':int(len(dists))}
