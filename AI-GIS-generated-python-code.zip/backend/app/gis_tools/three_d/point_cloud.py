def read_point_cloud_csv(path: str, x_col='x', y_col='y', z_col='z'):
    import pandas as pd
    df=pd.read_csv(path)
    for col in [x_col,y_col,z_col]:
        if col not in df.columns: raise ValueError(f'缺少坐标字段: {col}')
    return df
def dataframe_to_xyz(df, x_col='x', y_col='y', z_col='z'): return df[[x_col,y_col,z_col]].to_numpy(dtype=float)
