def export_volume_placeholder(output_path: str) -> str:
    with open(output_path,'w',encoding='utf-8') as f: f.write('# volume export placeholder\n')
    return output_path
