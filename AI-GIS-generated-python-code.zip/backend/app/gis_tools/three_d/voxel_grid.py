def create_voxel_grid(points_xyz, values=None, resolution=(50,50,20)) -> dict:
    import numpy as np
    pts=np.asarray(points_xyz,float); mins=pts.min(axis=0); maxs=pts.max(axis=0); axes=[np.linspace(mins[i], maxs[i], resolution[i]) for i in range(3)]
    return {'bounds':{'min':mins.tolist(),'max':maxs.tolist()},'resolution':list(resolution),'axes':[a.tolist() for a in axes]}
