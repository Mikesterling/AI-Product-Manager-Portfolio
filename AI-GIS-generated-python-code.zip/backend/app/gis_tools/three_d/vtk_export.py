def export_points_to_vtp(points_xyz, values, output_path: str) -> str:
    import numpy as np, pyvista as pv
    cloud=pv.PolyData(np.asarray(points_xyz,float))
    if values is not None: cloud['value']=np.asarray(values,float).reshape(-1)
    cloud.save(output_path); return output_path
