def get_feature_count(gdf) -> dict: return {'result_type':'feature_count','feature_count':int(len(gdf))}
def get_columns(gdf) -> dict: return {'result_type':'columns','columns':list(gdf.columns)}
def get_geometry_types(gdf) -> dict: return {'result_type':'geometry_types','geometry_types':gdf.geometry.geom_type.dropna().unique().tolist()}
def get_crs(gdf) -> dict: return {'result_type':'crs','crs':str(gdf.crs) if gdf.crs else '未知'}
def get_bounds(gdf) -> dict:
    minx,miny,maxx,maxy=gdf.total_bounds.tolist(); return {'result_type':'bounds','bounds':{'minx':minx,'miny':miny,'maxx':maxx,'maxy':maxy}}
def get_summary(gdf) -> dict:
    minx,miny,maxx,maxy=gdf.total_bounds.tolist()
    return {'result_type':'summary','feature_count':int(len(gdf)),'columns':list(gdf.columns),'crs':str(gdf.crs) if gdf.crs else '未知','geometry_types':gdf.geometry.geom_type.dropna().unique().tolist(),'bounds':{'minx':minx,'miny':miny,'maxx':maxx,'maxy':maxy}}
