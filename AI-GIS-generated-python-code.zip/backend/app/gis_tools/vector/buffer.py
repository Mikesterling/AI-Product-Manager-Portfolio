from app.utils.crs_utils import project_for_metric_calc
def buffer_vector(gdf, distance: float):
    metric=project_for_metric_calc(gdf); out=metric.copy(); out['geometry']=metric.geometry.buffer(distance)
    if gdf.crs and metric.crs != gdf.crs: out=out.to_crs(gdf.crs)
    return out
