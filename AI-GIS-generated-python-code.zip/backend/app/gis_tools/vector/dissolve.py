def dissolve_by_field(gdf, field: str):
    if field not in gdf.columns: raise ValueError(f'字段不存在: {field}')
    return gdf.dissolve(by=field).reset_index()
