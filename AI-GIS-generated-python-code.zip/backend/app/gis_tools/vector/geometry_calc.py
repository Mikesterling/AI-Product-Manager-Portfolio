from app.utils.crs_utils import project_for_metric_calc

def calculate_total_area(gdf) -> dict:
    geometry_types=set(gdf.geometry.geom_type.dropna().unique().tolist())
    if not geometry_types.issubset({'Polygon','MultiPolygon'}):
        return {'success':False,'result_type':'area','error':'当前文件不是纯面数据，无法计算总面积'}
    metric=project_for_metric_calc(gdf); return {'success':True,'result_type':'area','total_area':float(metric.area.sum()),'unit':'square_meter','note':'若原始数据为经纬度坐标，已临时投影到 EPSG:3857 后计算，单位近似为平方米'}

def calculate_total_length(gdf) -> dict:
    metric=project_for_metric_calc(gdf); return {'success':True,'result_type':'length','total_length':float(metric.length.sum()),'unit':'meter','note':'若原始数据为经纬度坐标，已临时投影到 EPSG:3857 后计算，单位近似为米'}

def calculate_centroids(gdf):
    out=gdf.copy(); metric=project_for_metric_calc(out); c=metric.geometry.centroid
    if out.crs and metric.crs != out.crs:
        import geopandas as gpd
        c=gpd.GeoSeries(c, crs=metric.crs).to_crs(out.crs)
    out['centroid_x']=c.x; out['centroid_y']=c.y; return out
