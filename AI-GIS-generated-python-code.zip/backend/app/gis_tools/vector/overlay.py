import geopandas as gpd
def overlay_intersection(left, right):
    if left.crs and right.crs and left.crs != right.crs: right=right.to_crs(left.crs)
    return gpd.overlay(left, right, how='intersection')
def overlay_union(left, right):
    if left.crs and right.crs and left.crs != right.crs: right=right.to_crs(left.crs)
    return gpd.overlay(left, right, how='union')
