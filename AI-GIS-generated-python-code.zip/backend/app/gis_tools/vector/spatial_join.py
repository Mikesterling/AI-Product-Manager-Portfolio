import geopandas as gpd
def spatial_join(left, right, predicate: str='intersects'):
    if left.crs and right.crs and left.crs != right.crs: right=right.to_crs(left.crs)
    return gpd.sjoin(left, right, how='left', predicate=predicate)
def nearest_join(left, right):
    if left.crs and right.crs and left.crs != right.crs: right=right.to_crs(left.crs)
    return gpd.sjoin_nearest(left, right, how='left', distance_col='nearest_distance')
