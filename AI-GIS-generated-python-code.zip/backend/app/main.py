from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes_upload import router as upload_router
from app.api.routes_analyze import router as analyze_router
from app.api.routes_map import router as map_router
from app.api.routes_ai import router as ai_router
from app.api.routes_task import router as task_router
from app.core.config import settings


def create_app() -> FastAPI:
    app = FastAPI(title=settings.PROJECT_NAME, version=settings.VERSION, description='AI-GIS backend')
    app.add_middleware(CORSMiddleware, allow_origins=settings.CORS_ORIGINS, allow_credentials=True, allow_methods=['*'], allow_headers=['*'])
    app.include_router(upload_router, prefix='/api/upload', tags=['Upload'])
    app.include_router(analyze_router, prefix='/api/analyze', tags=['Analyze'])
    app.include_router(map_router, prefix='/api/map', tags=['Map'])
    app.include_router(ai_router, prefix='/api/ai', tags=['AI'])
    app.include_router(task_router, prefix='/api/task', tags=['Task'])

    @app.get('/')
    def read_root():
        return {'success': True, 'message': 'AI-GIS backend is running', 'version': settings.VERSION}

    @app.get('/health')
    def health_check():
        return {'success': True, 'status': 'ok'}
    return app

app = create_app()
