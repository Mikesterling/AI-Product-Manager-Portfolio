from pydantic import BaseModel
class Bounds(BaseModel):
    minx: float; miny: float; maxx: float; maxy: float
class VectorSummary(BaseModel):
    feature_count: int
    columns: list[str]
    crs: str
    geometry_types: list[str]
    bounds: Bounds
