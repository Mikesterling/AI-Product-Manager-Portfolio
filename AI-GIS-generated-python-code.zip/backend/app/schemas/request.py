from pydantic import BaseModel, Field
class QueryRequest(BaseModel):
    text: str = Field(..., description='用户自然语言问题')
class DatasetAnalyzeRequest(BaseModel):
    dataset_id: str
    text: str
