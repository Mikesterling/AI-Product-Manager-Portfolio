from typing import Any
from pydantic import BaseModel
class BaseResponse(BaseModel):
    success: bool
    message: str | None = None
    data: Any | None = None
class ErrorResponse(BaseModel):
    success: bool = False
    error: str
