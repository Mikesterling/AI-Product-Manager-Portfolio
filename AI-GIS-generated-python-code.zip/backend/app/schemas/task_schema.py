from enum import Enum
from pydantic import BaseModel
class TaskStatus(str, Enum):
    pending='pending'; running='running'; success='success'; failed='failed'
class TaskInfo(BaseModel):
    task_id: str
    status: TaskStatus
    progress: float = 0.0
    message: str | None = None
