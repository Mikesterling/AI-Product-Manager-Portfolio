from app.ai_engine.intent_parser import parse_intent
def analyze_text_intent(text: str) -> dict: return {'success': True, 'input_text': text, 'intent': parse_intent(text)}
