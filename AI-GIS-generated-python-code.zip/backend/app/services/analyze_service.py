from app.services.file_service import read_vector_file
from app.ai_engine.tool_router import run_vector_tool
def analyze_vector_by_text(gdf, user_query: str) -> dict: return run_vector_tool(gdf, user_query)
def smart_analyze_file(file_path: str, user_query: str) -> dict:
    gdf=read_vector_file(file_path); return analyze_vector_by_text(gdf, user_query)
