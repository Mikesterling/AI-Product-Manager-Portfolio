from pathlib import Path
import geopandas as gpd
from app.core.config import settings
from app.utils.path_utils import add_uuid_prefix
from app.utils.shp_utils import extract_zip_to_folder, find_shp_file
async def save_upload_file(file) -> dict:
    filename=add_uuid_prefix(file.filename); save_path=settings.UPLOAD_DIR/filename; contents=await file.read()
    with open(save_path,'wb') as f: f.write(contents)
    return {'filename':file.filename,'saved_name':filename,'content_type':file.content_type,'size_bytes':len(contents),'saved_path':str(save_path)}
def read_vector_file(file_path: str | Path):
    path=Path(file_path); name=path.name.lower()
    if name.endswith(('.geojson','.json')): return gpd.read_file(path)
    if name.endswith('.zip'):
        extract_subdir=settings.EXTRACT_DIR/path.stem; extract_zip_to_folder(path, extract_subdir, clean=True); shp_path=find_shp_file(extract_subdir)
        if not shp_path: raise ValueError('压缩包中未找到 .shp 文件')
        return gpd.read_file(shp_path)
    if name.endswith('.shp'): return gpd.read_file(path)
    raise ValueError('目前仅支持 .geojson、.json、.shp、.zip 文件')
