from app.services.file_service import read_vector_file
from app.utils.geojson_utils import gdf_to_geojson_dict
def preview_vector_as_geojson(file_path, max_features: int=5000) -> dict:
    gdf=read_vector_file(file_path)
    if len(gdf)>max_features: gdf=gdf.head(max_features)
    return {'success': True, 'feature_count': len(gdf), 'geojson': gdf_to_geojson_dict(gdf)}
