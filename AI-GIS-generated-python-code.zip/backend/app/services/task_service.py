from uuid import uuid4
_TASKS={}
def create_task(message: str='任务已创建') -> dict:
    task_id=uuid4().hex; _TASKS[task_id]={'task_id':task_id,'status':'pending','progress':0.0,'message':message}; return _TASKS[task_id]
def get_task(task_id: str) -> dict: return _TASKS.get(task_id, {'task_id':task_id,'status':'not_found','progress':0.0,'message':'任务不存在'})
def update_task(task_id: str, status: str, progress: float, message: str | None=None) -> dict:
    _TASKS.setdefault(task_id, {'task_id':task_id}); _TASKS[task_id].update({'status':status,'progress':progress,'message':message}); return _TASKS[task_id]
