from app.services.file_service import save_upload_file
async def handle_upload(file) -> dict:
    saved=await save_upload_file(file); return {'success': True, **saved}
