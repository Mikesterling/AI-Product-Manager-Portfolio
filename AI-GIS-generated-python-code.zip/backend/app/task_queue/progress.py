_PROGRESS={}
def set_progress(task_id: str, value: float): _PROGRESS[task_id]=max(0.0, min(100.0, float(value)))
def get_progress(task_id: str) -> float: return _PROGRESS.get(task_id, 0.0)
