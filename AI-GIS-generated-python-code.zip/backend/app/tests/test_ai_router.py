from app.ai_engine.intent_parser import parse_intent
def test_parse_area(): assert parse_intent('计算面积')['tool']=='area'
