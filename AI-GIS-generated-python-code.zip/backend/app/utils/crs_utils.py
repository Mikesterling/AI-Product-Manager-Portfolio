def is_geographic_crs(gdf) -> bool: return bool(gdf.crs and gdf.crs.is_geographic)
def project_for_metric_calc(gdf, epsg: int=3857):
    if gdf.crs and gdf.crs.is_geographic: return gdf.to_crs(epsg=epsg)
    return gdf
