import json
def gdf_to_geojson_dict(gdf) -> dict: return json.loads(gdf.to_json())
def save_gdf_as_geojson(gdf, output_path: str) -> str:
    gdf.to_file(output_path, driver='GeoJSON'); return output_path
