from pathlib import Path
from uuid import uuid4
def safe_filename(filename: str) -> str: return filename.replace('/', '_').replace('\\', '_').strip()
def add_uuid_prefix(filename: str) -> str: return f'{uuid4().hex}_{safe_filename(filename)}'
def ensure_dir(path: str | Path) -> Path:
    p=Path(path); p.mkdir(parents=True, exist_ok=True); return p
