def ok(data=None, message: str | None=None) -> dict: return {'success': True, 'message': message, 'data': data}
def fail(error: str) -> dict: return {'success': False, 'error': error}
