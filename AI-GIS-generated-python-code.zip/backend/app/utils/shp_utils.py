import os, zipfile, shutil
from pathlib import Path

def find_shp_file(folder_path: str | Path) -> str | None:
    for root, _, files in os.walk(Path(folder_path)):
        for file in files:
            if file.lower().endswith('.shp'):
                return str(Path(root)/file)
    return None

def extract_zip_to_folder(zip_path: str | Path, extract_dir: str | Path, clean: bool=True) -> Path:
    zip_path=Path(zip_path); extract_dir=Path(extract_dir)
    if clean and extract_dir.exists(): shutil.rmtree(extract_dir)
    extract_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, 'r') as zip_ref: zip_ref.extractall(extract_dir)
    return extract_dir
