from pathlib import Path
import shutil
def clean_folder(folder: str):
    p=Path(folder);
    if p.exists(): shutil.rmtree(p)
    p.mkdir(parents=True, exist_ok=True); print(f'Cleaned: {p}')
if __name__ == '__main__': clean_folder('backend/outputs')
