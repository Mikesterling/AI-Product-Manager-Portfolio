import argparse, geopandas as gpd
def main():
    parser=argparse.ArgumentParser(); parser.add_argument('input_shp'); parser.add_argument('output_geojson'); args=parser.parse_args(); gpd.read_file(args.input_shp).to_file(args.output_geojson, driver='GeoJSON'); print(f'Saved: {args.output_geojson}')
if __name__ == '__main__': main()
