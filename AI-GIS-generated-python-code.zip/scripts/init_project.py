def main(): print('项目已初始化。建议进入 backend 后运行: python run.py')
if __name__ == '__main__': main()
