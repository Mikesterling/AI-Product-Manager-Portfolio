import requests
def main(): print(requests.get('http://127.0.0.1:8000/health', timeout=10).json())
if __name__ == '__main__': main()
